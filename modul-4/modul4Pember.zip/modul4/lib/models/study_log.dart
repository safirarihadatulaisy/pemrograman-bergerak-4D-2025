class StudyLog {
  final String id;
  final String tanggal;
  final String mataPelajaran;
  final int durasi;

  StudyLog({
    required this.id,
    required this.tanggal,
    required this.mataPelajaran,
    required this.durasi,
  });

  factory StudyLog.fromJson(Map<String, dynamic> json) {
    return StudyLog(
      id: json['id'] ?? '',
      tanggal: json['tanggal'] ?? '',
      mataPelajaran: json['mataPelajaran'] ?? '',
      durasi: json['durasi'] ?? 0,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'tanggal': tanggal,
      'mataPelajaran': mataPelajaran,
      'durasi': durasi,
    };
  }
}
