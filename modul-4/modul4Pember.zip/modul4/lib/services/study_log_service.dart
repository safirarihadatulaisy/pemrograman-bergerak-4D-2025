import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/study_log.dart';

class StudyLogService {
  static const String baseUrl =
      'https://belajarharian-afbaa-default-rtdb.asia-southeast1.firebasedatabase.app/Belajar.json'; // ganti sesuai project Firebase kamu

  static Future<List<StudyLog>> getStudyLogs() async {
    final response = await http.get(Uri.parse(baseUrl));
    final data = json.decode(response.body) as Map<String, dynamic>;
    List<StudyLog> logs = [];

    data.forEach((key, value) {
      logs.add(
        StudyLog(
          id: key,
          tanggal: value['tanggal'],
          mataPelajaran: value['mataPelajaran'],
          durasi: value['durasi'],
        ),
      );
    });

    return logs;
  }

  static Future<void> addStudyLog(StudyLog log) async {
    await http.post(Uri.parse(baseUrl), body: json.encode(log.toJson()));
  }

  static Future<void> updateStudyLog(String id, StudyLog log) async {
    final url =
        'https://belajarharian-afbaa-default-rtdb.asia-southeast1.firebasedatabase.app/Belajar/$id.json';
    await http.patch(Uri.parse(url), body: json.encode(log.toJson()));
  }

  static Future<void> deleteStudyLog(String id) async {
    final url =
        'https://belajarharian-afbaa-default-rtdb.asia-southeast1.firebasedatabase.app/Belajar/$id.json';
    await http.delete(Uri.parse(url));
  }
}
