import 'package:flutter/material.dart';
import '../models/study_log.dart';
import '../services/study_log_service.dart';

class AddEditScreen extends StatefulWidget {
  final StudyLog? log;

  AddEditScreen({this.log});

  @override
  _AddEditScreenState createState() => _AddEditScreenState();
}

class _AddEditScreenState extends State<AddEditScreen> {
  final _formKey = GlobalKey<FormState>();
  late String tanggal;
  late String mataPelajaran;
  late int durasi;

  @override
  void initState() {
    super.initState();
    tanggal = widget.log?.tanggal ?? '';
    mataPelajaran = widget.log?.mataPelajaran ?? '';
    durasi = widget.log?.durasi ?? 0;
  }

  void save() async {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
      final newLog = StudyLog(
        id: widget.log?.id ?? '',
        tanggal: tanggal,
        mataPelajaran: mataPelajaran,
        durasi: durasi,
      );

      try {
        if (widget.log == null) {
          await StudyLogService.addStudyLog(newLog);
        } else {
          await StudyLogService.updateStudyLog(widget.log!.id, newLog);
        }
        Navigator.pop(context); // kembali ke halaman sebelumnya
      } catch (e) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Gagal menyimpan data: $e')));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.log == null ? 'Tambah Log' : 'Edit Log',
          style: const TextStyle(color: Colors.white),
        ),
        backgroundColor: Colors.indigo,
        centerTitle: true,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              _buildTextField(
                label: 'Tanggal (YYYY-MM-DD)',
                initialValue: tanggal,
                onSaved: (val) => tanggal = val!,
              ),
              const SizedBox(height: 16),
              _buildTextField(
                label: 'Mata Pelajaran',
                initialValue: mataPelajaran,
                onSaved: (val) => mataPelajaran = val!,
              ),
              const SizedBox(height: 16),
              _buildTextField(
                label: 'Durasi Belajar (menit)',
                initialValue: durasi.toString(),
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value == null || value.isEmpty) return 'Wajib diisi';
                  if (int.tryParse(value) == null) return 'Harus berupa angka';
                  return null;
                },
                onSaved: (val) => durasi = int.tryParse(val ?? '0') ?? 0,
              ),
              const SizedBox(height: 30),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: save,
                  icon: const Icon(Icons.save, color: Colors.white),
                  label: const Text(
                    'Simpan',
                    style: TextStyle(color: Colors.white),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.indigo,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    textStyle: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTextField({
    required String label,
    required String initialValue,
    TextInputType keyboardType = TextInputType.text,
    FormFieldValidator<String>? validator,
    required FormFieldSetter<String> onSaved,
  }) {
    return TextFormField(
      initialValue: initialValue,
      keyboardType: keyboardType,
      decoration: InputDecoration(
        labelText: label,
        filled: true,
        fillColor: Colors.grey[100],
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Colors.indigo, width: 2),
        ),
      ),
      validator:
          validator ??
          (value) => (value == null || value.isEmpty) ? 'Wajib diisi' : null,
      onSaved: onSaved,
    );
  }
}
