package com.example.modul4

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
