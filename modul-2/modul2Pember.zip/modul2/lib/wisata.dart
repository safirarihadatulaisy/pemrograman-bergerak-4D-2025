import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:typed_data';

class TambahWisata extends StatefulWidget {
  const TambahWisata({super.key});

  @override
  State<TambahWisata> createState() => _TambahWisataState();
}

class _TambahWisataState extends State<TambahWisata> {
  final _formKey = GlobalKey<FormState>();
  Uint8List? _imageBytes;
  final picker = ImagePicker();

  String? _nama;
  String? _lokasi;
  String? _harga;
  String? _deskripsi;
  String? _jenisWisata;

  final List<String> jenisWisataList = [
    'Wisata Alam',
    'Wisata Sejarah',
    'Wisata Keluarga',
    'Wisata Edukasi',
    'Wisata Kuliner',
  ];

  Future<void> _getImage() async {
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      final bytes = await pickedFile.readAsBytes();
      setState(() {
        _imageBytes = bytes;
      });
    }
  }

  void _submitForm() {
    if (_formKey.currentState!.validate() && _imageBytes != null) {
      _formKey.currentState!.save();

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Data wisata berhasil disimpan."),
          backgroundColor: Colors.green,
        ),
      );

      Navigator.pop(context, {
        'nama': _nama,
        'lokasi': _lokasi,
        'harga': _harga,
        'deskripsi': _deskripsi,
        'jenis': _jenisWisata,
        'gambar': _imageBytes,
      });

      _formKey.currentState!.reset();
      setState(() {
        _imageBytes = null;
        _jenisWisata = null;
      });
    } else if (_imageBytes == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Gambar wajib diunggah."),
          backgroundColor: Colors.redAccent,
        ),
      );
    }
  }

  void _resetForm() {
    _formKey.currentState!.reset();
    setState(() {
      _imageBytes = null;
      _jenisWisata = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Tambah Wisata"),
        centerTitle: true,
        leading: const BackButton(color: Colors.black),
        backgroundColor: Colors.white,
        elevation: 0,
        foregroundColor: Colors.black,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              Container(
                height: 160,
                decoration: BoxDecoration(
                  color: Colors.grey[200],
                  borderRadius: BorderRadius.circular(12),
                ),
                child:
                    _imageBytes == null
                        ? const Center(
                          child: Icon(
                            Icons.add_photo_alternate,
                            size: 60,
                            color: Colors.grey,
                          ),
                        )
                        : ClipRRect(
                          borderRadius: BorderRadius.circular(12),
                          child: Image.memory(_imageBytes!, fit: BoxFit.cover),
                        ),
              ),
              const SizedBox(height: 12),
              ElevatedButton(
                onPressed: _getImage,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.indigo,
                  foregroundColor: Colors.white,
                  minimumSize: const Size.fromHeight(40),
                ),
                child: const Text("Upload Image"),
              ),
              const SizedBox(height: 20),

              _buildLabeledField(
                "Nama Wisata",
                TextFormField(
                  decoration: _inputDecoration("Masukkan Nama Wisata Disini"),
                  validator:
                      (val) =>
                          val == null || val.isEmpty ? "Wajib diisi" : null,
                  onSaved: (val) => _nama = val,
                ),
              ),

              const SizedBox(height: 12),

              _buildLabeledField(
                "Lokasi Wisata",
                TextFormField(
                  decoration: _inputDecoration("Masukkan Lokasi Wisata Disini"),
                  validator:
                      (val) =>
                          val == null || val.isEmpty ? "Wajib diisi" : null,
                  onSaved: (val) => _lokasi = val,
                ),
              ),

              const SizedBox(height: 12),

              _buildLabeledField(
                "Jenis Wisata",
                DropdownButtonFormField<String>(
                  value: _jenisWisata,
                  decoration: _inputDecoration("Pilih Jenis Wisata"),
                  items:
                      jenisWisataList.map((String value) {
                        return DropdownMenuItem<String>(
                          value: value,
                          child: Text(value),
                        );
                      }).toList(),
                  onChanged: (val) {
                    setState(() {
                      _jenisWisata = val!;
                    });
                  },
                  onSaved: (val) => _jenisWisata = val,
                  validator:
                      (val) =>
                          val == null ? "Pilih salah satu jenis wisata" : null,
                ),
              ),

              const SizedBox(height: 12),

              _buildLabeledField(
                "Harga Tiket",
                TextFormField(
                  keyboardType: TextInputType.number,
                  decoration: _inputDecoration("Masukkan Harga Tiket Disini"),
                  validator:
                      (val) =>
                          val == null || val.isEmpty ? "Wajib diisi" : null,
                  onSaved: (val) => _harga = val,
                ),
              ),

              const SizedBox(height: 12),

              _buildLabeledField(
                "Deskripsi",
                TextFormField(
                  maxLines: 3,
                  decoration: _inputDecoration("Masukkan Deskripsi Disini"),
                  validator:
                      (val) =>
                          val == null || val.isEmpty ? "Wajib diisi" : null,
                  onSaved: (val) => _deskripsi = val,
                ),
              ),

              const SizedBox(height: 20),

              ElevatedButton(
                onPressed: _submitForm,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.indigo,
                  foregroundColor: Colors.white,
                  minimumSize: const Size.fromHeight(40),
                ),
                child: const Text("Simpan"),
              ),

              const SizedBox(height: 8),

              TextButton(
                onPressed: _resetForm,
                child: const Text(
                  "Reset",
                  style: TextStyle(color: Colors.indigo),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  InputDecoration _inputDecoration(String hint) {
    return InputDecoration(
      hintText: hint,
      filled: true,
      fillColor: Colors.grey[200],
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: BorderSide.none,
      ),
      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
    );
  }

  Widget _buildLabeledField(String label, Widget field) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
        ),
        const SizedBox(height: 6),
        field,
      ],
    );
  }
}
