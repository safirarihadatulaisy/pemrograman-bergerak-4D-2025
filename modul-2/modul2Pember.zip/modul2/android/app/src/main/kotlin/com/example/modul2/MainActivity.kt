package com.example.modul2

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
