package com.example.modul1praktikum

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
