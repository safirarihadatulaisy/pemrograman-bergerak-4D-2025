package com.example.coba_kamera

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
